import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import HeroSection from '@/components/sections/HeroSection';
import AboutSection from '@/components/sections/AboutSection';
import ServicesSection from '@/components/sections/ServicesSection';
import GallerySection from '@/components/sections/GallerySection';
import DesignersSection from '@/components/sections/DesignersSection';
import ReviewsSection from '@/components/sections/ReviewsSection';
import ServiceDetailsSection from '@/components/sections/ServiceDetailsSection';

import ReserveCTASection from '@/components/sections/ReserveCTASection';


export default function Home() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-deep-black text-ivory overflow-x-hidden">
      <Navigation scrollY={scrollY} />
      <main>
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <ServiceDetailsSection />
        <GallerySection />

        <DesignersSection />
        <ReviewsSection />
        <ReserveCTASection />
      </main>
      <Footer />
    </div>
  );
}
