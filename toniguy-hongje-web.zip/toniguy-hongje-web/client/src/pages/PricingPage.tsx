import { useState } from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { ChevronDown } from 'lucide-react';

interface PricingCategory {
  name: string;
  description: string;
  services: Array<{
    name: string;
    price: number;
    description?: string;
  }>;
}

const pricingData: PricingCategory[] = [
  {
    name: '커트 (Cut)',
    description: '직급별 디자이너 차등요금 있습니다',
    services: [
      { name: '트리밍 CUT', price: 30000 },
      { name: '체인지 CUT', price: 35000 },
      { name: '학생 & 어린이 CUT', price: 20000 },
      { name: '헤드스파컷', price: 50000 },
      { name: '알머리 CUT', price: 8000 }
    ]
  },
  {
    name: '펌 (Perm)',
    description: '다양한 펌 기술로 원하는 웨이브 완성',
    services: [
      { name: 'PERM (노멀)', price: 80000 },
      { name: 'PERM (스페셜)', price: 110000 },
      { name: 'PERM (프리미엄)', price: 140000 },
      { name: 'HEATING PERM (열펌) - 노멀', price: 170000 },
      { name: 'HEATING PERM (열펌) - 스페셜', price: 200000 },
      { name: 'HEATING PERM (열펌) - 프리미엄', price: 230000 },
      { name: 'MAGIC SETTING PERM - 노멀', price: 245000, description: '매직 셋팅펌' },
      { name: 'MAGIC SETTING PERM - 스페셜', price: 275000 },
      { name: 'MAGIC SETTING PERM - 프리미엄', price: 305000 },
      { name: 'ONE PART PERM (뿌리 펌)', price: 70000 },
      { name: 'ONE PART PERM (다운펌)', price: 50000 },
      { name: 'ONE PART PERM (앞머리 앞)', price: 25000 },
      { name: 'ONE PART PERM (앞머리 옆)', price: 35000 }
    ]
  },
  {
    name: '염색 (Color)',
    description: '트렌드 컬러를 두피 건강을 지키며 구현',
    services: [
      { name: 'COLOR (노멀)', price: 80000 },
      { name: 'COLOR (스페셜)', price: 110000 },
      { name: 'COLOR (프리미엄)', price: 140000 },
      { name: 'DIA BLEACH COLOR', price: 100000 },
      { name: 'DIA BLEACH COLOR (뿌리염색)', price: 70000 },
      { name: 'ROOT STAINING (뿌리 염색)', price: 70000, description: '3cm 이하' },
      { name: 'COLOR (컬러 전문 클리닉)', price: 50000 }
    ]
  },
  {
    name: '클리닉 (Clinic)',
    description: '손상된 모발을 회복시키는 맞춤형 케어',
    services: [
      { name: 'CLINIC (첫 번도)', price: 200000 },
      { name: 'CLINIC (노멀)', price: 60000 },
      { name: 'CLINIC (스페셜)', price: 100000 },
      { name: 'PREMIUM CLINIC (프리미엄클리닉)', price: 80000 },
      { name: 'RECOVERY CLINIC (복구클리닉)', price: 120000 }
    ]
  },
  {
    name: '헤드스파 (Head Spa)',
    description: '건강한 두피에서 아름다운 머리카락이 시작',
    services: [
      { name: '헤드스파 (25분)', price: 50000 },
      { name: '비불스파 (1회/25분)', price: 50000 },
      { name: '비불스파 5회 + 추가 1회 S/V', price: 250000 },
      { name: '타임프로스파 (1회/40분)', price: 80000 },
      { name: '타임프로스파 5회 + 추가 1회 S/V', price: 400000 },
      { name: '릴렉싱스파 (1회/60분)', price: 120000 },
      { name: '릴렉싱스파 5회 + 추가 1회 S/V', price: 600000 }
    ]
  },
  {
    name: '스타일링 & 기타 (Styling)',
    description: '드라이, 메이크업 등 추가 서비스',
    services: [
      { name: '드라이 (매직/아이롱/매직)', price: 30000 },
      { name: '행사드라이', price: 40000 },
      { name: '스타일링', price: 15000 },
      { name: '샴푸', price: 15000 },
      { name: '메이크업', price: 100000 },
      { name: '업스타일', price: 100000 },
      { name: '세미 업스타일', price: 60000 }
    ]
  }
];

export default function PricingPage() {
  const [scrollY, setScrollY] = useState(0);
  const [expandedCategory, setExpandedCategory] = useState<number | null>(0);

  const handleScroll = () => setScrollY(window.scrollY);
  window.addEventListener('scroll', handleScroll);

  const formatPrice = (price: number) => {
    return price.toLocaleString('ko-KR');
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#f4efe8' }}>
      <Navigation scrollY={scrollY} />
      
      <main className="pt-32 pb-24">
        <div className="container max-w-6xl">
          {/* Header */}
          <div className="mb-16 text-center">
            <div className="section-tag" style={{ color: '#b8965a' }}>
              PRICING
            </div>
            <h1 className="text-5xl md:text-6xl font-light mb-4" style={{ color: '#0d0c0b' }}>
              가격표
            </h1>
            <p className="text-lg" style={{ color: '#6a6460' }}>
              TONI&GUY 홍제점의 모든 서비스와 가격을 확인하세요
            </p>
          </div>

          {/* Pricing Categories */}
          <div className="space-y-6">
            {pricingData.map((category, idx) => (
              <div
                key={idx}
                className="rounded-lg overflow-hidden"
                style={{ backgroundColor: '#ffffff', border: '1px solid #e8ddd2' }}
              >
                {/* Category Header */}
                <button
                  onClick={() => setExpandedCategory(expandedCategory === idx ? null : idx)}
                  className="w-full p-6 flex items-center justify-between hover:bg-opacity-50 transition-colors"
                  style={{ backgroundColor: '#f9f6f1' }}
                >
                  <div className="text-left">
                    <h2 className="text-2xl font-light mb-2" style={{ color: '#0d0c0b' }}>
                      {category.name}
                    </h2>
                    <p style={{ color: '#6a6460' }}>
                      {category.description}
                    </p>
                  </div>
                  <ChevronDown
                    size={24}
                    style={{
                      color: '#b8965a',
                      transform: expandedCategory === idx ? 'rotate(180deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s ease'
                    }}
                  />
                </button>

                {/* Services List */}
                {expandedCategory === idx && (
                  <div className="p-6 space-y-4 border-t" style={{ borderColor: '#e8ddd2' }}>
                    {category.services.map((service, serviceIdx) => (
                      <div
                        key={serviceIdx}
                        className="flex items-center justify-between pb-4"
                        style={{
                          borderBottom: serviceIdx < category.services.length - 1 ? '1px solid #f0ebe5' : 'none'
                        }}
                      >
                        <div className="flex-1">
                          <p className="font-light text-lg" style={{ color: '#0d0c0b' }}>
                            {service.name}
                          </p>
                          {service.description && (
                            <p className="text-sm" style={{ color: '#6a6460' }}>
                              {service.description}
                            </p>
                          )}
                        </div>
                        <div
                          className="px-4 py-2 rounded text-lg font-light"
                          style={{
                            backgroundColor: '#b8965a',
                            color: '#ffffff'
                          }}
                        >
                          ₩{formatPrice(service.price)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Additional Info */}
          <div className="mt-16 p-8 rounded-lg" style={{ backgroundColor: '#ffffff', border: '1px solid #e8ddd2' }}>
            <h3 className="text-2xl font-light mb-6" style={{ color: '#0d0c0b' }}>
              추가 요금 & 참고사항
            </h3>
            <div className="space-y-4" style={{ color: '#6a6460' }}>
              <p>
                <span style={{ color: '#0d0c0b', fontWeight: 500 }}>어깨 아래:</span> +20,000원
              </p>
              <p>
                <span style={{ color: '#0d0c0b', fontWeight: 500 }}>가슴 아래:</span> +30,000원
              </p>
              <p>
                <span style={{ color: '#0d0c0b', fontWeight: 500 }}>기본 가격:</span> 직급별 디자이너 차등요금이 있습니다
              </p>
              <p>
                <span style={{ color: '#0d0c0b', fontWeight: 500 }}>컷트:</span> 별도 계산됩니다
              </p>
              <p>
                <span style={{ color: '#0d0c0b', fontWeight: 500 }}>가격정보:</span> 시술별 기본가격을 기준으로 제공합니다
              </p>
            </div>
          </div>

          {/* Contact CTA */}
          <div className="mt-16 text-center">
            <p className="text-lg mb-6" style={{ color: '#6a6460' }}>
              더 자세한 상담이 필요하신가요?
            </p>
            <div className="flex flex-col md:flex-row gap-4 justify-center">
              <a
                href="tel:02-396-2805"
                className="px-8 py-3 rounded text-lg font-light transition-colors"
                style={{
                  backgroundColor: '#b8965a',
                  color: '#ffffff'
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#d4b07a')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#b8965a')}
              >
                전화 예약: 02) 396-2805
              </a>
              <a
                href="https://naver.me/x2POPhAu"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-3 rounded text-lg font-light transition-colors"
                style={{
                  backgroundColor: '#0d0c0b',
                  color: '#f4efe8'
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#2a2926')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#0d0c0b')}
              >
                네이버 예약
              </a>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
