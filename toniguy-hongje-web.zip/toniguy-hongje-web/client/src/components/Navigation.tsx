import { useState } from 'react';
import { Menu, X } from 'lucide-react';

interface NavigationProps {
  scrollY: number;
}

export default function Navigation({ scrollY }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Designers', href: '#designers' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Pricing', href: '/pricing' },
    { label: 'Blog', href: 'https://m.blog.naver.com/p750616', external: true },
  ];

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrollY > 50 ? 'py-3 backdrop-blur-sm' : 'py-7'
      }`}
      style={{
        backgroundColor: scrollY > 50 ? 'rgba(8, 8, 8, 0.8)' : '#080808',
        mixBlendMode: 'difference'
      }}
    >
      <div className="container flex justify-between items-center">
        <a href="#" className="nav-font text-ivory text-lg tracking-widest">
          TONI&GUY · 홍제
        </a>

        {/* Desktop Menu */}
        <div className="hidden md:flex gap-10 items-center">
          <ul className="flex gap-10">
            {navLinks.map((link) => (
              <li key={link.label}>
                <a
                  href={link.href}
                  target={link.external ? '_blank' : undefined}
                  rel={link.external ? 'noopener noreferrer' : undefined}
                  className="nav-font text-xs text-ivory opacity-70 hover:opacity-100 transition-opacity"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="tel:027396-2805"
            className="text-xs px-6 py-2 tracking-wider uppercase transition-colors"
            style={{
              fontFamily: "'Josefin Sans', sans-serif",
              fontWeight: 100,
              letterSpacing: '0.1em',
              color: '#080808',
              backgroundColor: '#f4efe8'
            }}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#d4b07a')}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#f4efe8')}
          >
            예약하기
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden text-ivory p-2"
          aria-label="Toggle menu"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden fixed inset-0 top-20 z-40 flex flex-col items-center justify-center gap-8" style={{ backgroundColor: '#080808' }}>
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              target={link.external ? '_blank' : undefined}
              rel={link.external ? 'noopener noreferrer' : undefined}
              className="text-2xl font-cormorant font-light italic transition-colors"
              style={{ color: '#f4efe8' }}
              onMouseEnter={(e) => (e.currentTarget.style.color = '#b8965a')}
              onMouseLeave={(e) => (e.currentTarget.style.color = '#f4efe8')}
              onClick={() => setIsOpen(false)}
            >
              {link.label}
            </a>
          ))}
          <a
            href="tel:027396-2805"
            className="text-2xl font-cormorant font-light italic transition-colors"
            style={{ color: '#b8965a' }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#d4b07a')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#b8965a')}
            onClick={() => setIsOpen(false)}
          >
            예약하기
          </a>
        </div>
      )}
    </nav>
  );
}
