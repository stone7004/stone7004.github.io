import { useEffect, useRef, useState } from 'react';

const galleryItems = [
  { label: '엄기억 · Art Director', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_013909_NAVER_70ce2b4b.jpg' },
  { label: '안나 · Senior Designer', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_013552_NAVER_f59200f7.jpg' },
  { label: '가희 · Specialist', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_014553_NAVER_2faf6528.jpg' },
  { label: '수호 · Specialist', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015009_NAVER_27e8b377.jpg' },
  { label: '은지 · Designer', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015126_NAVER_2255ea2d.jpg' },
  { label: '서진 · Designer', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015436_NAVER_7325b1c7.jpg' },
  { label: '솔빈 · Designer', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015629_NAVER_15f72070.jpg' },
  { label: '케빈 · Designer', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_013027_NAVER_07eff228.jpg' },
  { label: '진 · Vice Director', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015754_NAVER_f6a6c8c3.jpg' },
  { label: '진 · Vice Director (프로필)', img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_030722_Manus_090a36e0.jpg' }
];

export default function GallerySection() {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="gallery" className="py-24 md:py-32 bg-deep-black">
      <div className="container max-w-6xl">
        <div
          ref={ref}
          className={`mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="section-tag">Style Gallery</div>
          <h2 className="section-title">스타일 갤러리</h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {galleryItems.map((item, idx) => (
            <div
              key={idx}
              className={`relative aspect-square overflow-hidden group transition-all duration-1000 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${idx * 50}ms` }}
            >
              <img
                src={item.img}
                alt={item.label}
                className="w-full h-full object-cover grayscale-[20%] contrast-110 group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <p className="tag-font text-gold p-4">{item.label}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <a
            href="https://m.blog.naver.com/p750616"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary"
          >
            네이버 블로그에서 더 보기
          </a>
        </div>
      </div>
    </section>
  );
}
