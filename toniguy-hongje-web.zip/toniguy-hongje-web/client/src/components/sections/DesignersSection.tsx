import { useEffect, useRef, useState } from 'react';

const designers = [
  {
    name: '엄기억',
    role: 'Art Director · 대표원장',
    experience: '30년',
    specialty: '시니어 볼륨컷, 볼륨펌, 레이어드컷',
    desc: 'TONI&GUY 영국 크리에이티브 컷 디플로마 소유. 꼼꼼한 상담으로 얼굴형에 맞는 완벽한 스타일 제안. KBS 2TV 인간극장 5회 출연, 유명 연예인 다수 헤어 담당.',
    specialties: ['시니어 볼륨컷', '볼륨펌', '레이어드컷', '디자인보브컷', '헤드스파'],
    representative: ['시니어 볼륨 웨이브 (100,000원)', '우아한 레이어드 스타일 (40,000원)', '프리미엄 클리닉 (80,000원)'],
    time: '1.5~3시간',
    img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_013909_NAVER_70ce2b4b.jpg'
  },
  {
    name: '안나',
    role: 'Senior Designer · 실장',
    experience: '26년',
    specialty: '레이어드컷, 손상모펌, 남성컷',
    desc: '단순한 헤어가 아닌, 당신만의 분위기와 매력을 살리는 스타일을 만듭니다. 고객 한 분, 한 분의 얼굴형, 모질, 라이프스타일까지 고려해 매일 거울 앞에서 기분 좋아지는 헤어를 디자인합니다.',
    specialties: ['레이어드컷', '손상 최소화 펌', '남성컷', '블리치 컬러', '루트 스테이닝'],
    representative: ['레이어드 롱 웨이브 (40,000원)', '손상 최소화 펌 (80,000원)', '남성 컷 (35,000원)'],
    time: '1~3시간',
    img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_013552_NAVER_f59200f7.jpg'
  },
  {
    name: '가희',
    role: 'Specialist · 실장',
    experience: '8년+',
    specialty: '히든펌, 탈모커버펌, 컬러',
    desc: '일상을 이해하는 단 하나의 디자인 저와 함께 달라집니다. 고객님의 라이프 스타일에 맞게 아름다운 디자인을 선물해드리겠습니다.',
    specialties: ['히든펌', '탈모커버펌', '컬러', '헤드스파', '클리닉'],
    representative: ['히든펌 (100,000원)', '탈모커버펌 (120,000원)', '프리미엄 컬러 (80,000원)'],
    time: '1.5~3시간',
    img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_014553_NAVER_2faf6528.jpg'
  },
  {
    name: '수호',
    role: 'Specialist · 실장',
    experience: '10년+',
    specialty: '멘즈스타일, 아이롱펌, 다운펌',
    desc: '멘즈 스타일 NO.1, 재방문율 NO.1. 한분만을 위한 디자인으로 인생머리 만들어드립니다. 고객님의 라이프 스타일에 맞게 아름다운 디자인을 선물해드리겠습니다.',
    specialties: ['아이롱펌', '다운펌', '가일컷', '애즈펌', '시스루댄디'],
    representative: ['남성 아이롱펌 (80,000원)', '트렌드 쇼트 컷 (35,000원)', '다운펌 (80,000원)'],
    time: '30분~2.5시간',
    img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015009_NAVER_27e8b377.jpg'
  },
  {
    name: '은지',
    role: 'Designer · 디자이너',
    experience: '7년+',
    specialty: '레이어드컷&펌, 슬릭컷&펌, 허쉬컷&펌',
    desc: '평범한 일상에 특별한 분위기를 더하다. 트렌디한 디자인으로 당신만을 위한 맞춤 시그니처 스타일로 함께 하겠습니다.',
    specialties: ['레이어드컷&펌', '슬릭컷&펌', '허쉬컷&펌', '헤드스파', '클리닉'],
    representative: ['레이어드 웨이브 (100,000원)', '슬릭 스타일 (80,000원)', '허쉬 펌 (90,000원)'],
    time: '1.5~3시간',
    img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015126_NAVER_2255ea2d.jpg'
  },
  {
    name: '서진',
    role: 'Designer · 디자이너',
    experience: '5년+',
    specialty: '디테일한 상담, 두상과 얼굴형 맞춤',
    desc: '디테일하고 구체적인 상담을 통해 두상과 얼굴형, 모질에 맞는 스타일을 제안하고 관리해드립니다. 불편함을 줄이고 스타일의 완성도는 높이되, 손질 편한 디자인으로 평소에도 멋진 스타일을 디자인해드리겠습니다.',
    specialties: ['여성 디자인 컷', '펌 & 웨이브', '컬러링', '헤드스파', '클리닉'],
    representative: ['맞춤 여성 컷 (40,000원)', '펌 & 웨이브 (80,000원)', '프리미엄 컬러 (80,000원)'],
    time: '1~3시간',
    img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015436_NAVER_7325b1c7.jpg'
  },
  {
    name: '솔빈',
    role: 'Designer · 디자이너',
    experience: '8년+',
    specialty: '매직 전문, 레이어드컷 전문',
    desc: '레이어드컷과 크리스탈 매직을 사랑하는 솔빈입니다. 각자의 얼굴형과 모발에 맞는 맞춤 디자인으로 손상 없이 건강한 머릿결을 유지하면서 스타일을 만들어드릴게요. 끊임없는 연구와 노력으로 항상 최신 트렌드를 선도하는 디자이너 되겠습니다.',
    specialties: ['매직스트레이트', '레이어드컷', '젤리펌', '헤드스파', '프리미엄 클리닉'],
    representative: ['매직스트레이트 + 컬러 (180,000원)', '젤리펌 + 클리닉 (160,000원)', '릴렉싱 헤드스파 (120,000원)'],
    time: '1.5~3.5시간',
    img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015629_NAVER_15f72070.jpg'
  },
  {
    name: '케빈',
    role: 'Designer · 디자이너',
    experience: '5년+',
    specialty: '여성 펌, 여성 염색, 맞춤 상담',
    desc: '꼼꼼하고 세련된 케빈만의 오롯이 손끝 감성으로 집에서도 손질한 재현성 100%의 스타일을 느껴보세요! 1:1 맞춤 상담 후 꼼꼼하게 시술 해 드리겠습니다. 고객님의 라이프 스타일에 맞게 아름다운 디자인을 선물해드리겠습니다.',
    specialties: ['여성 펌', '여성 염색', '맞춤 컷', '헤드스파', '클리닉'],
    representative: ['여성 펌 (80,000원)', '여성 염색 (80,000원)', '맞춤 여성 컷 (40,000원)'],
    time: '1~3시간',
    img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_013027_NAVER_07eff228.jpg'
  },
  {
    name: '진',
    role: 'Vice Director · 부원장',
    experience: '25년',
    specialty: '단발컷&펌, 보브컷&펌, 매직셋팅&펌',
    desc: '회원님을 위한 1:1 맞춤 상담과 25년 전문가의 손길을 담아 디자인 해드리겠습니다. 고객님의 라이프 스타일에 맞게 아름다운 디자인을 선물해드리겠습니다.',
    specialties: ['단발컷&펌', '보브컷&펌', '매직셋팅&펌', '컬러', '클리닉'],
    representative: ['단발 펌 (80,000원)', '보브 스타일 (40,000원)', '매직셋팅 (120,000원)'],
    time: '1.5~3시간',
    img: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/Screenshot_20260402_015754_NAVER_40bb2ed1.jpg'
  }
];

export default function DesignersSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [expandedDesigner, setExpandedDesigner] = useState<string | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="designers" className="py-24 md:py-32" style={{ backgroundColor: '#0d0c0b' }}>
      <div className="container max-w-6xl">
        <div
          ref={ref}
          className={`mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="section-tag">Our Team</div>
          <h2 className="section-title" style={{ color: '#f4efe8' }}>
            디자이너
          </h2>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {designers.map((designer, idx) => (
            <div
              key={designer.name}
              className={`transition-all duration-1000 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${idx * 100}ms` }}
            >
              <div className="relative aspect-square overflow-hidden group mb-4">
                <img
                  src={designer.img}
                  alt={designer.name}
                  className="w-full h-full object-cover grayscale-[20%] contrast-110 group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <a
                    href="https://m.blog.naver.com/p750616"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="tag-font transition-colors"
                    style={{ color: '#b8965a' }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = '#d4b07a')}
                    onMouseLeave={(e) => (e.currentTarget.style.color = '#b8965a')}
                  >
                    작품 보기
                  </a>
                </div>
              </div>
              <h3 className="text-lg font-light mb-1" style={{ color: '#f4efe8' }}>
                {designer.name}
              </h3>
              <p className="tag-font mb-2" style={{ color: '#b8965a' }}>
                {designer.role}
              </p>
              <p className="text-xs mb-3" style={{ color: '#c8c2ba' }}>
                <span style={{ color: '#6a6460' }}>경력:</span> {designer.experience}
              </p>
              <p className="text-xs mb-3" style={{ color: '#c8c2ba' }}>
                <span style={{ color: '#6a6460' }}>전문:</span> {designer.specialty}
              </p>
              <p className="text-xs leading-relaxed mb-4" style={{ color: '#c8c2ba' }}>
                {designer.desc}
              </p>
              
              {/* 전문 분야 */}
              <div className="mb-4 pb-4" style={{ borderBottom: '1px solid #3a3530' }}>
                <p className="text-xs font-semibold mb-2" style={{ color: '#b8965a' }}>
                  전문 분야
                </p>
                <div className="flex flex-wrap gap-1">
                  {designer.specialties.map((spec) => (
                    <span
                      key={spec}
                      className="text-xs px-2 py-1 rounded"
                      style={{ backgroundColor: '#2a2520', color: '#c8c2ba' }}
                    >
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              {/* 대표 시술 */}
              <div className="mb-4 pb-4" style={{ borderBottom: '1px solid #3a3530' }}>
                <p className="text-xs font-semibold mb-2" style={{ color: '#b8965a' }}>
                  대표 시술
                </p>
                <ul className="text-xs space-y-1">
                  {designer.representative.map((rep) => (
                    <li key={rep} style={{ color: '#c8c2ba' }}>
                      • {rep}
                    </li>
                  ))}
                </ul>
              </div>

              {/* 소요 시간 */}
              <p className="text-xs" style={{ color: '#c8c2ba' }}>
                <span style={{ color: '#6a6460' }}>소요시간:</span> {designer.time}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
