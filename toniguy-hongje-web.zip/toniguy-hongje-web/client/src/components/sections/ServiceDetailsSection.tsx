import { useState } from 'react';
import { ChevronRight } from 'lucide-react';

interface ServiceDetail {
  id: string;
  name: string;
  price: string;
  duration: string;
  description: string;
  benefits: string[];
  suitable: string;
  aftercare: string;
}

const serviceDetails: ServiceDetail[] = [
  {
    id: 'cut',
    name: '커트 (Cut)',
    price: '30,000원~',
    duration: '30~40분',
    description: '두상과 얼굴형을 정밀하게 분석하여 고객의 라이프스타일과 개성에 맞춘 맞춤형 커트입니다. TONI&GUY의 크리에이티브 커팅 기법으로 트렌드를 반영한 스타일을 제안합니다.',
    benefits: [
      '얼굴형에 최적화된 라인 설계',
      '손질이 쉬운 스타일 완성',
      '개인의 매력을 극대화하는 디자인',
      '트렌드를 반영한 현대적 스타일'
    ],
    suitable: '모든 연령대 및 얼굴형에 맞춤 가능',
    aftercare: '일주일에 한 번 가볍게 드라이하고, 2~3주마다 정기적인 손질 권장'
  },
  {
    id: 'perm',
    name: '펌 (Perm)',
    price: '80,000원~',
    duration: '2~3시간',
    description: '다양한 펌 기술(노멀, 스페셜, 프리미엄)로 원하는 웨이브와 볼륨감을 완성합니다. 머릿결의 손상을 최소화하면서 오래 지속되는 펌을 제공합니다.',
    benefits: [
      '자연스러운 웨이브 완성',
      '오래 지속되는 펌 효과 (4~6주)',
      '매일 스타일링 시간 단축',
      '머릿결 건강 유지'
    ],
    suitable: '직모, 곱슬머리, 볼륨이 필요한 고객',
    aftercare: '펌 후 24시간은 머리를 감지 않기. 주 2~3회 트리트먼트 시술 권장'
  },
  {
    id: 'color',
    name: '염색 (Color)',
    price: '80,000원~',
    duration: '1.5~2시간',
    description: '실버그레이, 바이올렛, 코발트 애쉬 등 트렌드 컬러를 두피 건강을 지키면서 구현합니다. 개인의 피부톤에 맞춘 맞춤형 컬러 제안이 특징입니다.',
    benefits: [
      '피부톤에 맞춘 컬러 선택',
      '두피 손상 최소화',
      '생생한 색감 표현',
      '오래 지속되는 컬러 (4~6주)'
    ],
    suitable: '이미지 변신을 원하는 모든 고객',
    aftercare: '염색 후 3일간 찬바람 드라이 권장. 주 1~2회 컬러 에센스 팩 사용'
  },
  {
    id: 'clinic',
    name: '클리닉 (Clinic)',
    price: '40,000원~',
    duration: '1~1.5시간',
    description: '손상된 모발을 집중 케어하는 프리미엄 트리트먼트입니다. 단백질, 케라틴, 에센스를 깊숙이 침투시켜 건강하고 탄력 있는 머릿결을 되찾습니다.',
    benefits: [
      '손상된 모발 회복',
      '윤기 있는 머릿결',
      '탄력과 부드러움 증진',
      '갈라짐 방지'
    ],
    suitable: '펌, 염색, 매직 후 손상된 모발. 건조한 머릿결',
    aftercare: '클리닉 후 24시간 드라이 금지. 주 1회 정기 시술 권장'
  },
  {
    id: 'headspa',
    name: '헤드스파 (Head Spa)',
    price: '50,000원~',
    duration: '25~60분',
    description: '두피를 깊숙이 클렌징하고 마사지하여 스트레스를 해소하고 건강한 두피 환경을 만듭니다. 아로마테라피와 함께 완벽한 힐링 경험을 제공합니다.',
    benefits: [
      '두피 스트레스 해소',
      '혈액순환 촉진',
      '건강한 두피 환경 조성',
      '완벽한 힐링 경험'
    ],
    suitable: '스트레스가 많은 고객, 두피가 민감한 고객, 탈모 예방 원하는 고객',
    aftercare: '시술 후 2시간 이내 머리 감지 않기. 월 1~2회 정기 시술 권장'
  },
  {
    id: 'magic',
    name: '매직 스트레이트 (Magic Straight)',
    price: '80,000원~',
    duration: '2~3시간',
    description: '곱슬거리고 손상된 머릿결을 매끄럽고 윤기 있게 펴줍니다. 클리닉 효과와 스트레이트 펌을 동시에 받는 프리미엄 시술입니다.',
    benefits: [
      '매끄러운 스트레이트 완성',
      '윤기 있는 머릿결',
      '손상 최소화',
      '오래 지속되는 효과 (3~4개월)'
    ],
    suitable: '곱슬머리, 손상된 머릿결, 매끄러운 스타일 원하는 고객',
    aftercare: '매직 후 72시간 머리 감지 않기. 주 1회 트리트먼트 시술 권장'
  }
];

export default function ServiceDetailsSection() {
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const selected = serviceDetails.find(s => s.id === selectedService);

  return (
    <section id="service-details" className="py-20" style={{ backgroundColor: '#f4efe8' }}>
      <div className="container max-w-6xl">
        {/* Header */}
        <div className="mb-16 text-center">
          <div className="section-tag" style={{ color: '#b8965a' }}>
            SERVICE DETAILS
          </div>
          <h2 className="text-5xl md:text-6xl font-light mb-4" style={{ color: '#0d0c0b' }}>
            서비스 안내
          </h2>
          <p className="text-lg" style={{ color: '#6a6460' }}>
            각 서비스에 대한 상세한 설명과 효과를 확인하세요
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Service List */}
          <div className="space-y-3">
            {serviceDetails.map((service) => (
              <button
                key={service.id}
                onClick={() => setSelectedService(service.id)}
                className="w-full p-4 rounded-lg text-left transition-all"
                style={{
                  backgroundColor: selectedService === service.id ? '#b8965a' : '#ffffff',
                  color: selectedService === service.id ? '#ffffff' : '#0d0c0b',
                  border: `1px solid ${selectedService === service.id ? '#b8965a' : '#e8ddd2'}`
                }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-light text-lg">{service.name}</p>
                    <p className="text-sm" style={{ opacity: 0.7 }}>
                      {service.price} • {service.duration}
                    </p>
                  </div>
                  <ChevronRight size={20} />
                </div>
              </button>
            ))}
          </div>

          {/* Service Details */}
          <div
            className="p-8 rounded-lg"
            style={{ backgroundColor: '#ffffff', border: '1px solid #e8ddd2' }}
          >
            {selected ? (
              <div className="space-y-6">
                <div>
                  <h3 className="text-3xl font-light mb-2" style={{ color: '#0d0c0b' }}>
                    {selected.name}
                  </h3>
                  <p className="text-lg" style={{ color: '#b8965a' }}>
                    {selected.price} • {selected.duration}
                  </p>
                </div>

                <div>
                  <p style={{ color: '#6a6460', lineHeight: '1.8' }}>
                    {selected.description}
                  </p>
                </div>

                <div>
                  <p className="font-light mb-3" style={{ color: '#0d0c0b' }}>
                    주요 효과
                  </p>
                  <ul className="space-y-2">
                    {selected.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <span
                          className="inline-block w-2 h-2 rounded-full mt-2"
                          style={{ backgroundColor: '#b8965a' }}
                        ></span>
                        <span style={{ color: '#6a6460' }}>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <p className="font-light mb-2" style={{ color: '#0d0c0b' }}>
                    추천 대상
                  </p>
                  <p style={{ color: '#6a6460' }}>{selected.suitable}</p>
                </div>

                <div>
                  <p className="font-light mb-2" style={{ color: '#0d0c0b' }}>
                    관리 방법
                  </p>
                  <p style={{ color: '#6a6460' }}>{selected.aftercare}</p>
                </div>

                <button
                  className="w-full py-3 rounded-lg font-light transition-colors"
                  style={{
                    backgroundColor: '#b8965a',
                    color: '#ffffff'
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#d4b07a')}
                  onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#b8965a')}
                >
                  예약하기
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-center h-full" style={{ color: '#6a6460' }}>
                <p>좌측에서 서비스를 선택하면 상세 정보가 표시됩니다</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
