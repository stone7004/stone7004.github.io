import { useEffect, useRef, useState } from 'react';
import { Star } from 'lucide-react';

const reviews = [
  {
    name: '김미영',
    service: '시니어 볼륨컷',
    rating: 5,
    content: '엄기억 대표님의 시니어 볼륨컷 정말 최고예요. 얼굴형에 맞게 완벽하게 잘라주셔서 손질도 편하고 스타일도 예뻐요. 매번 방문할 때마다 만족합니다.',
    designer: '엄기억'
  },
  {
    name: '박수진',
    service: '매직스트레이트',
    rating: 5,
    content: '솔빈 디자이너의 크리스탈 매직 정말 좋아요. 머릿결 손상 없이 자연스럽고 매끄러운 스트레이트가 완성돼요. 시술 후 관리법도 자세히 설명해주셔서 감사합니다.',
    designer: '솔빈'
  },
  {
    name: '이준호',
    service: '남성 아이롱펌',
    rating: 5,
    content: '수호 실장님의 남성 아이롱펌 정말 추천합니다. 세련되고 트렌디한 스타일로 완성해주셨어요. 펌이 자연스럽고 오래가서 정기적으로 방문하고 있습니다.',
    designer: '수호'
  },
  {
    name: '이영희',
    service: '헤드스파 & 두피케어',
    rating: 5,
    content: '솔빈 디자이너의 헤드스파 정말 힐링돼요. 두피가 한결 개운해지고 머릿결도 부드러워져요. 겨울철 두피 건강 관리에 최고입니다.',
    designer: '솔빈'
  },
  {
    name: '최지은',
    service: '레이어드컷 & 염색',
    rating: 5,
    content: '안나 실장님의 레이어드컷과 염색 정말 좋아요. 트렌디한 스타일로 완벽하게 변신했어요. 상담도 꼼꼼하고 시술도 정성스럽습니다.',
    designer: '안나'
  },
  {
    name: '정민지',
    service: '젤리펌',
    rating: 5,
    content: '솔빈 디자이너의 젤리펌 정말 탄력있고 예뻐요. 고데기 한 듯 자연스러운 웨이브가 오래 유지돼요. 20대 트렌드 펌 추천합니다!',
    designer: '솔빈'
  }
];

export default function ReviewsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const goToPrevious = () => {
    setActiveIndex((prev) => (prev === 0 ? reviews.length - 1 : prev - 1));
  };

  const goToNext = () => {
    setActiveIndex((prev) => (prev === reviews.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="reviews" className="py-24 md:py-32" style={{ backgroundColor: '#f4efe8' }}>
      <div className="container max-w-6xl">
        <div
          ref={ref}
          className={`mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="section-tag" style={{ color: '#b8965a' }}>
            CUSTOMER REVIEWS
          </div>
          <h2 className="section-title" style={{ color: '#0d0c0b' }}>
            고객 후기
          </h2>
          <p className="mt-4 text-lg" style={{ color: '#6a6460' }}>
            4.95/5.0 평점 · 10,216개 리뷰
          </p>
        </div>

        <div className="relative">
          {/* Review Carousel */}
          <div className="overflow-hidden rounded-lg">
            <div
              className="transition-all duration-500 ease-out"
              style={{
                transform: `translateX(-${activeIndex * 100}%)`,
              }}
            >
              <div className="flex">
                {reviews.map((review, idx) => (
                  <div
                    key={idx}
                    className="w-full flex-shrink-0 p-8 md:p-12"
                    style={{ backgroundColor: '#ffffff', borderLeft: '4px solid #b8965a' }}
                  >
                    <div className="flex items-center gap-2 mb-4">
                      {Array.from({ length: review.rating }).map((_, i) => (
                        <Star
                          key={i}
                          size={20}
                          fill="#b8965a"
                          stroke="#b8965a"
                        />
                      ))}
                    </div>

                    <p
                      className="text-lg leading-relaxed mb-6"
                      style={{ color: '#0d0c0b' }}
                    >
                      "{review.content}"
                    </p>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold" style={{ color: '#0d0c0b' }}>
                          {review.name}
                        </p>
                        <p className="text-sm" style={{ color: '#6a6460' }}>
                          {review.service}
                        </p>
                      </div>
                      <div
                        className="px-4 py-2 rounded text-sm font-light"
                        style={{
                          backgroundColor: '#b8965a',
                          color: '#ffffff'
                        }}
                      >
                        {review.designer}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={goToPrevious}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-16 md:-translate-x-20 p-2 transition-colors"
            style={{ color: '#b8965a' }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#d4b07a')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#b8965a')}
            aria-label="Previous review"
          >
            <svg
              width="32"
              height="32"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <polyline points="15 18 9 12 15 6"></polyline>
            </svg>
          </button>

          <button
            onClick={goToNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-16 md:translate-x-20 p-2 transition-colors"
            style={{ color: '#b8965a' }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#d4b07a')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#b8965a')}
            aria-label="Next review"
          >
            <svg
              width="32"
              height="32"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
          </button>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-2 mt-8">
            {reviews.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setActiveIndex(idx)}
                className="transition-all duration-300"
                style={{
                  width: activeIndex === idx ? '32px' : '8px',
                  height: '8px',
                  backgroundColor: activeIndex === idx ? '#b8965a' : '#d4b07a',
                  borderRadius: '4px',
                  border: 'none',
                  cursor: 'pointer'
                }}
                aria-label={`Go to review ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
