import { useState } from "react";
import { ChevronDown } from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
  category: "service" | "reservation" | "parking";
}

const faqItems: FAQItem[] = [
  {
    category: "service",
    question: "각 시술별 소요 시간은 얼마나 되나요?",
    answer:
      "커트는 30~40분, 펌은 2~3시간, 염색은 1.5~2시간, 클리닉은 1~1.5시간, 헤드스파는 25~60분(코스에 따라 다름), 매직스트레이트는 2~3시간 소요됩니다. 복합 시술의 경우 더 오래 걸릴 수 있습니다.",
  },
  {
    category: "service",
    question: "처음 방문하는데 어떤 준비가 필요한가요?",
    answer:
      "특별한 준비물은 없습니다. 다만 시술 전 머리를 감지 않으신 상태로 방문하시면 두피 보호에 좋습니다. 원하는 스타일이 있다면 사진을 준비해오시면 상담 시 도움이 됩니다.",
  },
  {
    category: "service",
    question: "펌이나 염색 후 관리 방법은?",
    answer:
      "펌 후 24시간은 머리를 감지 않으시는 것이 좋습니다. 염색 후 3일간은 찬바람으로 드라이하시고, 일주일에 2~3회 정도 트리트먼트 팩을 사용하시면 색감 유지에 도움됩니다. 자세한 관리법은 시술 후 디자이너가 설명해드립니다.",
  },
  {
    category: "service",
    question: "손상된 머릿결 개선이 가능한가요?",
    answer:
      "네, 가능합니다. 클리닉, 프리미엄 클리닉, 복구 클리닉 등 손상 정도에 따라 맞춤형 트리트먼트를 제공합니다. 정기적인 관리(2~3주마다)로 건강한 머릿결을 되찾을 수 있습니다.",
  },
  {
    category: "reservation",
    question: "예약은 어떻게 하나요?",
    answer:
      "전화(02-396-2805), 네이버 블로그 예약, 카카오 채널을 통해 예약 가능합니다. 전화 예약이 가장 빠르며, 원하는 디자이너와 시술을 지정할 수 있습니다.",
  },
  {
    category: "reservation",
    question: "당일 예약이 가능한가요?",
    answer:
      "가능합니다만, 디자이너 스케줄에 따라 대기 시간이 발생할 수 있습니다. 가능한 한 사전에 예약하시는 것을 권장합니다. 긴급한 경우 전화로 문의해주세요.",
  },
  {
    category: "reservation",
    question: "예약 취소나 변경은?",
    answer:
      "예약 취소나 변경은 최소 24시간 전에 연락주시기 바랍니다. 당일 취소는 시술료의 50%가 발생할 수 있습니다.",
  },
  {
    category: "parking",
    question: "주차 시설이 있나요?",
    answer:
      "건물 지하에 주차 공간이 있습니다. 시술 고객은 무료 주차 가능합니다. 주차 공간이 제한적이므로 대중교통 이용을 권장합니다.",
  },
  {
    category: "parking",
    question: "대중교통으로 가는 방법은?",
    answer:
      "지하철: 3호선 홍제역 1번 출구에서 도보 5분. 버스: 통일로 정류장(마을버스 1020번, 간선버스 7, 7-1번) 근처입니다. 정확한 위치는 네이버 지도에서 '홍제치유온한의원'을 검색하시면 됩니다.",
  },
  {
    category: "parking",
    question: "영업 시간은?",
    answer:
      "화요일~일요일 10:00~20:00 운영합니다. 월요일은 휴무입니다. 공휴일은 정상 운영합니다.",
  },
];

export default function FAQSection() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState<"service" | "reservation" | "parking">(
    "service"
  );

  const filteredFAQs = faqItems.filter((item) => item.category === activeCategory);

  const categoryLabels = {
    service: "시술 안내",
    reservation: "예약 정보",
    parking: "오시는 길",
  };

  return (
    <section id="faq" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif text-deep-black mb-4">
            자주 묻는 질문
          </h2>
          <p className="text-lg text-gray-600">
            시술, 예약, 오시는 길에 대해 자주 묻는 질문들입니다
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex justify-center gap-4 mb-12 flex-wrap">
          {(["service", "reservation", "parking"] as const).map((category) => (
            <button
              key={category}
              onClick={() => {
                setActiveCategory(category);
                setExpandedIndex(null);
              }}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                activeCategory === category
                  ? "bg-gold text-white shadow-lg"
                  : "bg-light-gray text-deep-black hover:bg-gray-300"
              }`}
            >
              {categoryLabels[category]}
            </button>
          ))}
        </div>

        {/* FAQ Items */}
        <div className="max-w-3xl mx-auto space-y-4">
          {filteredFAQs.map((item, index) => (
            <div
              key={index}
              className="border border-light-gray rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-300"
            >
              <button
                onClick={() => setExpandedIndex(expandedIndex === index ? null : index)}
                className="w-full px-6 py-4 flex items-center justify-between bg-ivory hover:bg-gray-50 transition-colors duration-200"
              >
                <span className="text-left text-lg font-medium text-deep-black">
                  {item.question}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-gold transition-transform duration-300 flex-shrink-0 ml-4 ${
                    expandedIndex === index ? "rotate-180" : ""
                  }`}
                />
              </button>

              {expandedIndex === index && (
                <div className="px-6 py-4 bg-white border-t border-light-gray">
                  <p className="text-gray-700 leading-relaxed">{item.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 bg-ivory rounded-lg p-8 max-w-3xl mx-auto">
          <h3 className="text-2xl font-serif text-deep-black mb-4">더 궁금한 점이 있으신가요?</h3>
          <p className="text-gray-700 mb-6">
            위의 FAQ에서 찾지 못한 질문이 있다면 언제든지 연락주세요.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="tel:02-396-2805"
              className="px-6 py-3 bg-gold text-white rounded-lg font-medium hover:bg-gold-light transition-colors duration-300 text-center"
            >
              전화 상담 (02-396-2805)
            </a>
            <a
              href="http://pf.kakao.com/_ZHCXj"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 border-2 border-gold text-gold rounded-lg font-medium hover:bg-gold hover:text-white transition-colors duration-300 text-center"
            >
              카카오 채널 상담
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
