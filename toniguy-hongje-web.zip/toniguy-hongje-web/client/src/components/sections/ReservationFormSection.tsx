import { useState } from 'react';
import { Calendar, Clock, User, Scissors, Phone, Mail } from 'lucide-react';

interface ReservationFormData {
  date: string;
  time: string;
  designer: string;
  service: string;
  name: string;
  phone: string;
  email: string;
  notes: string;
}

const designers = [
  { id: 'giumeok', name: '엄기억 (대표원장)', specialty: '시니어 볼륨컷, 볼륨펌' },
  { id: 'anna', name: '안나 (실장)', specialty: '레이어드컷, 손상모펌' },
  { id: 'gahee', name: '가희 (실장)', specialty: '히든펌, 탈모커버펌' },
  { id: 'suho', name: '수호 (실장)', specialty: '남성 펌, 아이롱펌' },
  { id: 'eunji', name: '은지 (디자이너)', specialty: '레이어드컷&펌, 슬릭컷' },
  { id: 'seojin', name: '서진 (디자이너)', specialty: '여성 디자인 컷, 펌' },
  { id: 'solbin', name: '솔빈 (디자이너)', specialty: '매직스트레이트, 젤리펌' },
  { id: 'kevin', name: '케빈 (디자이너)', specialty: '여성 펌, 여성 염색' },
  { id: 'jin', name: '진 (부원장)', specialty: '단발컷&펌, 보브컷&펌' },
];

const services = [
  { id: 'cut', name: '커트', duration: '30~40분', price: '30,000원~' },
  { id: 'perm', name: '펌', duration: '2~3시간', price: '80,000원~' },
  { id: 'color', name: '염색', duration: '1.5~2시간', price: '80,000원~' },
  { id: 'clinic', name: '클리닉', duration: '1~1.5시간', price: '40,000원~' },
  { id: 'headspa', name: '헤드스파', duration: '25~60분', price: '50,000원~' },
  { id: 'magic', name: '매직스트레이트', duration: '2~3시간', price: '80,000원~' },
  { id: 'hairClinic', name: '모발 클리닉', duration: '1~2시간', price: '80,000원~' },
  { id: 'scalpCovering', name: '두피 커버링', duration: '1.5~2시간', price: '별도 상담' },
  { id: 'hidden', name: '히든펌', duration: '2~3시간', price: '100,000원~' },
  { id: 'volumePerm', name: '볼륨펌', duration: '2~3시간', price: '100,000원~' },
];

const timeSlots = [
  '10:00', '10:30', '11:00', '11:30', '12:00', '12:30',
  '13:00', '13:30', '14:00', '14:30', '15:00', '15:30',
  '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30'
];

export default function ReservationFormSection() {
  const [formData, setFormData] = useState<ReservationFormData>({
    date: '',
    time: '',
    designer: '',
    service: '',
    name: '',
    phone: '',
    email: '',
    notes: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.date) newErrors.date = '날짜를 선택해주세요';
    if (!formData.time) newErrors.time = '시간을 선택해주세요';
    if (!formData.designer) newErrors.designer = '디자이너를 선택해주세요';
    if (!formData.service) newErrors.service = '시술을 선택해주세요';
    if (!formData.name) newErrors.name = '이름을 입력해주세요';
    if (!formData.phone) newErrors.phone = '전화번호를 입력해주세요';
    if (formData.phone && !/^01[0-9]-?\d{3,4}-?\d{4}$/.test(formData.phone)) {
      newErrors.phone = '올바른 전화번호 형식입니다 (010-1234-5678)';
    }
    if (!formData.email) newErrors.email = '이메일을 입력해주세요';
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = '올바른 이메일 형식입니다';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    // 예약 정보를 콘솔에 출력 (실제로는 서버로 전송)
    console.log('Reservation submitted:', formData);

    // 예약 완료 메시지 표시
    setSubmitted(true);

    // 3초 후 폼 초기화
    setTimeout(() => {
      setFormData({
        date: '',
        time: '',
        designer: '',
        service: '',
        name: '',
        phone: '',
        email: '',
        notes: '',
      });
      setSubmitted(false);
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
    // 입력 시 해당 필드의 에러 제거
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  // 예약 가능한 날짜 계산 (오늘부터 60일 후까지)
  const getMinDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  const getMaxDate = () => {
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 60);
    return maxDate.toISOString().split('T')[0];
  };

  const selectedService = services.find(s => s.id === formData.service);
  const selectedDesigner = designers.find(d => d.id === formData.designer);

  return (
    <section id="reservation-form" className="py-20 bg-ivory">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif text-deep-black mb-4">
            온라인 예약
          </h2>
          <p className="text-lg text-gray-600">
            원하는 날짜, 시간, 디자이너, 시술을 선택하여 예약하세요
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          {submitted ? (
            <div className="bg-green-50 border-2 border-green-500 rounded-lg p-8 text-center">
              <div className="text-5xl mb-4">✓</div>
              <h3 className="text-2xl font-serif text-deep-black mb-2">예약이 접수되었습니다!</h3>
              <p className="text-gray-700 mb-4">
                {formData.name}님의 예약 정보가 저장되었습니다.
              </p>
              <p className="text-sm text-gray-600">
                확인 전화는 {formData.phone}으로 연락드리겠습니다.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-lg shadow-lg">
              {/* Date Selection */}
              <div>
                <label className="block text-sm font-medium text-deep-black mb-2 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gold" />
                  예약 날짜
                </label>
                <input
                  type="date"
                  name="date"
                  value={formData.date}
                  onChange={handleChange}
                  min={getMinDate()}
                  max={getMaxDate()}
                  className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gold transition-all ${
                    errors.date ? 'border-red-500 focus:ring-red-500' : 'border-light-gray'
                  }`}
                />
                {errors.date && <p className="text-red-500 text-sm mt-1">{errors.date}</p>}
              </div>

              {/* Time Selection */}
              <div>
                <label className="block text-sm font-medium text-deep-black mb-2 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gold" />
                  예약 시간
                </label>
                <select
                  name="time"
                  value={formData.time}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gold transition-all ${
                    errors.time ? 'border-red-500 focus:ring-red-500' : 'border-light-gray'
                  }`}
                >
                  <option value="">시간을 선택해주세요</option>
                  {timeSlots.map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
                {errors.time && <p className="text-red-500 text-sm mt-1">{errors.time}</p>}
              </div>

              {/* Designer Selection */}
              <div>
                <label className="block text-sm font-medium text-deep-black mb-2 flex items-center gap-2">
                  <User className="w-4 h-4 text-gold" />
                  디자이너 선택
                </label>
                <select
                  name="designer"
                  value={formData.designer}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gold transition-all ${
                    errors.designer ? 'border-red-500 focus:ring-red-500' : 'border-light-gray'
                  }`}
                >
                  <option value="">디자이너를 선택해주세요</option>
                  {designers.map(designer => (
                    <option key={designer.id} value={designer.id}>
                      {designer.name} - {designer.specialty}
                    </option>
                  ))}
                </select>
                {errors.designer && <p className="text-red-500 text-sm mt-1">{errors.designer}</p>}
              </div>

              {/* Service Selection */}
              <div>
                <label className="block text-sm font-medium text-deep-black mb-2 flex items-center gap-2">
                  <Scissors className="w-4 h-4 text-gold" />
                  시술 선택
                </label>
                <select
                  name="service"
                  value={formData.service}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gold transition-all ${
                    errors.service ? 'border-red-500 focus:ring-red-500' : 'border-light-gray'
                  }`}
                >
                  <option value="">시술을 선택해주세요</option>
                  {services.map(service => (
                    <option key={service.id} value={service.id}>
                      {service.name} - {service.duration} ({service.price})
                    </option>
                  ))}
                </select>
                {errors.service && <p className="text-red-500 text-sm mt-1">{errors.service}</p>}
              </div>

              {/* Service Info Display */}
              {selectedService && (
                <div className="bg-gold bg-opacity-10 border-l-4 border-gold p-4 rounded">
                  <p className="text-sm text-deep-black">
                    <strong>예상 시술 시간:</strong> {selectedService.duration}
                  </p>
                </div>
              )}

              {/* Divider */}
              <div className="border-t border-light-gray pt-6">
                <h3 className="text-lg font-medium text-deep-black mb-4">고객 정보</h3>
              </div>

              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-deep-black mb-2">
                  이름 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="이름을 입력해주세요"
                  className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gold transition-all ${
                    errors.name ? 'border-red-500 focus:ring-red-500' : 'border-light-gray'
                  }`}
                />
                {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-medium text-deep-black mb-2 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-gold" />
                  전화번호 <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="010-1234-5678"
                  className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gold transition-all ${
                    errors.phone ? 'border-red-500 focus:ring-red-500' : 'border-light-gray'
                  }`}
                />
                {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-deep-black mb-2 flex items-center gap-2">
                  <Mail className="w-4 h-4 text-gold" />
                  이메일 <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="example@email.com"
                  className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gold transition-all ${
                    errors.email ? 'border-red-500 focus:ring-red-500' : 'border-light-gray'
                  }`}
                />
                {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-deep-black mb-2">
                  특별 요청사항 (선택)
                </label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                  placeholder="원하시는 스타일이나 특별한 요청사항을 입력해주세요"
                  rows={4}
                  className="w-full px-4 py-3 border border-light-gray rounded-lg focus:outline-none focus:ring-2 focus:ring-gold transition-all resize-none"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full px-6 py-4 bg-gold text-white rounded-lg font-medium hover:bg-gold-light transition-colors duration-300 text-lg"
              >
                예약하기
              </button>

              {/* Info Text */}
              <p className="text-center text-sm text-gray-600">
                예약 후 확인 전화를 드리겠습니다. 긴급한 경우 <strong>02-396-2805</strong>로 연락주세요.<br />
                <span className="text-xs mt-2 block">주차 공간이 협소하니 대중교통 이용을 권장합니다. 시술 금액에 따라 일부 주차비를 지원해드립니다.</span>
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
