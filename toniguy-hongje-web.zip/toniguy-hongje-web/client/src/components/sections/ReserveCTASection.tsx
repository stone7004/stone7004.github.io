import { useEffect, useRef, useState } from 'react';
import { MapPin, Clock, Instagram } from 'lucide-react';

export default function ReserveCTASection() {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="reserve" className="py-24 md:py-32 bg-[#0d0c0b]">
      <div
        ref={ref}
        className={`container max-w-4xl text-center transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="section-tag">Reservation</div>
        <h2 className="section-title text-black">지금 바로 예약하세요</h2>

        <a
          href="tel:+82-2-396-2805"
          className="inline-block font-cormorant text-5xl md:text-6xl font-light text-gold mb-8 hover:text-gold-light transition-colors"
        >
          02) 396-2805
        </a>

        <div className="flex flex-col gap-4 mb-12 items-center">
          <a href="tel:+82-2-396-2805" className="btn-primary w-full md:w-auto text-center">
            전화 예약
          </a>
          <a
            href="https://booking.naver.com/booking/13/bizes/49697"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary w-full md:w-auto text-center"
          >
            네이버 예약
          </a>
          <a
            href="http://pf.kakao.com/_ZHCXj"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary w-full md:w-auto text-center"
          >
            카카오 채널
          </a>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mt-16 pt-12 border-t border-white/10">
          <div className="flex flex-col items-center gap-3">
            <MapPin className="text-gold" size={24} />
            <div>
              <p className="tag-font text-gold mb-2">Location</p>
              <p className="text-sm text-light-gray">
                서울 서대문구 통일로 437<br />
                홍제치유온한의원 2층
              </p>
            </div>
          </div>

          <div className="flex flex-col items-center gap-3">
            <Clock className="text-gold" size={24} />
            <div>
              <p className="tag-font text-gold mb-2">Hours</p>
              <p className="text-sm text-light-gray">
                매일 10:00 – 19:00<br />
                연중무휴
              </p>
            </div>
          </div>

          <div className="flex flex-col items-center gap-3">
            <Instagram className="text-gold" size={24} />
            <div>
              <p className="tag-font text-gold mb-2">Instagram</p>
              <a
                href="https://www.instagram.com/toniguy_hongje"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-light-gray hover:text-gold transition-colors"
              >
                @toniguy_hongje
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
