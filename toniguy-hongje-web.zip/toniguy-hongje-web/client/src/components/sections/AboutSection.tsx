import { useEffect, useRef, useState } from 'react';

const ABOUT_IMAGE_MAIN = 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/about-image-main-BdwzUPkywpEXzWzAnoxQNm.webp';
const ABOUT_IMAGE_ACCENT = 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/about-image-accent-in9DdJU3Q3dVHaRLR6kNER.webp';

export default function AboutSection() {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" className="py-24 md:py-32 bg-deep-black">
      <div className="container max-w-6xl">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          {/* Images */}
          <div
            ref={ref}
            className={`relative transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
            }`}
          >
            <div className="relative aspect-[3/4] overflow-hidden">
              {/* Badge */}
              <div className="absolute top-0 left-0 w-24 h-24 bg-gold flex flex-col items-center justify-center z-10 -translate-x-6 -translate-y-6">
                <div className="font-cormorant text-3xl font-light text-deep-black">9+</div>
                <div className="tag-font text-deep-black text-xs">YEARS</div>
              </div>

              {/* Main Image */}
              <img
                src={ABOUT_IMAGE_MAIN}
                alt="TONI&GUY 홍제점 내부"
                className="w-full h-full object-cover grayscale-[30%] contrast-110"
              />
            </div>

            {/* Accent Image */}
            <div className="hidden md:block absolute bottom-0 right-0 w-1/2 aspect-square -translate-y-12 translate-x-12">
              <img
                src={ABOUT_IMAGE_ACCENT}
                alt="헤어 스타일"
                className="w-full h-full object-cover border-4 border-deep-black grayscale-[20%]"
              />
            </div>
          </div>

          {/* Text Content */}
          <div
            className={`transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
            }`}
          >
            <div className="section-tag">About TONI&GUY 홍제</div>
            <h2 className="section-title">
              런던이
              <br />
              홍제에
              <br />
              <span className="text-gold italic">오다</span>
            </h2>

            <div className="space-y-6 text-light-gray text-sm md:text-base leading-relaxed">
              <p>
                TONI&GUY 홍제점은 2015년 서울 서대문구 홍제에 문을 열었습니다. 런던 패션위크에서 탄생한 글로벌 헤어 브랜드의 철학을 이어받아, 매 시즌 트렌드를 앞서가는 헤어 스타일을 제안합니다.
              </p>
              <p>
                수석 디자이너 엄기억을 중심으로, 고객 한 분 한 분의 라이프스타일과 두상 특성에 맞춘 맞춤형 시술을 제공합니다. 클리닉부터 컬러까지, 모든 과정이 예술입니다.
              </p>
            </div>

            {/* Stats */}
            <div className="mt-12 pt-8 border-t border-white/10 flex gap-12">
              <div className="text-center">
                <div className="font-cormorant text-3xl md:text-4xl font-light text-gold">3,000+</div>
                <div className="tag-font text-medium-gray mt-2">Satisfied Clients</div>
              </div>
              <div className="text-center">
                <div className="font-cormorant text-3xl md:text-4xl font-light text-gold">9</div>
                <div className="tag-font text-medium-gray mt-2">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="font-cormorant text-3xl md:text-4xl font-light text-gold">100%</div>
                <div className="tag-font text-medium-gray mt-2">Satisfaction</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
