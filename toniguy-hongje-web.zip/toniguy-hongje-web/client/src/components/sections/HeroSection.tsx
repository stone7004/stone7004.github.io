import { useEffect, useState } from 'react';
import { ChevronDown } from 'lucide-react';



export default function HeroSection() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section
      id="top"
      className="relative h-screen flex items-center overflow-hidden"
      style={{ backgroundColor: '#080808' }}
    >
      {/* Black Background Only */}
      <div className="absolute inset-0" style={{ backgroundColor: '#080808' }} />

      {/* Content */}
      <div className="container relative z-10 max-w-2xl px-4 md:px-0">
        <div className="space-y-4 md:space-y-8">
          {/* Tag */}
          <div
            className={`tag-font text-xs md:text-sm transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '0.3s', color: '#b8965a' }}
          >
            <span className="hidden md:inline">London Fashion Week · Seoul Hongje · Since 2015</span>
            <span className="md:hidden">TONI&GUY · HONGJE</span>
          </div>

          {/* Title */}
          <h1
            className={`hero-title text-4xl md:text-6xl transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '0.5s', color: '#f4efe8' }}
          >
            Art of
            <br />
            <span style={{ color: '#b8965a' }}>Hair</span>
          </h1>

          {/* Subtitle */}
          <p
            className={`text-xs md:text-sm leading-relaxed max-w-xs md:max-w-md transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '0.7s', color: '#c8c2ba' }}
          >
            <span className="hidden md:inline">서울 홍제 · 서대문구 통일로 437<br />런던 패션위크의 감각을 홍제에서 만나다</span>
            <span className="md:hidden">서울 홍제<br />런던 패션위크의 감각</span>
          </p>

          {/* CTA Buttons */}
          <div
            className={`flex flex-col gap-3 md:gap-4 transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '0.9s' }}
          >
            <a
              href="tel:+82-2-396-2805"
              className="btn-primary text-center text-sm md:text-base"
            >
              지금 예약하기
            </a>
            <a
              href="#gallery"
              className="btn-secondary text-center text-sm md:text-base"
            >
              스타일 보기
            </a>
          </div>
        </div>
      </div>

      {/* Scroll Hint - Desktop Only */}
      <div
        className={`hidden md:flex absolute bottom-8 left-1/2 -translate-x-1/2 flex-col items-center gap-2 transition-all duration-1000 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
        style={{ transitionDelay: '1.4s', animation: 'bounce 2s infinite 2s' }}
      >
        <span className="tag-font" style={{ color: '#c8c2ba' }}>Scroll</span>
        <div
          className="w-0.5 h-12"
          style={{
            backgroundImage: 'linear-gradient(to bottom, #b8965a, transparent)',
            animation: 'scrollDrop 2s ease-in-out infinite'
          }}
        />
      </div>
    </section>
  );
}
