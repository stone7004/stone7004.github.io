import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface MonthlyStyle {
  id: number;
  title: string;
  description: string;
  image: string;
  designer: string;
  category: string;
}

const monthlyStyles: MonthlyStyle[] = [
  {
    id: 1,
    title: '시니어 볼륨 웨이브',
    description: '성숙한 매력을 살린 우아한 웨이브. 얼굴형을 보완하고 세련된 분위기를 연출합니다. 100,000원 / 2~3시간',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/wY1L9zUhpXxe_78cfc05c.jpg',
    designer: '엄기억 (대표원장)',
    category: '펌/웨이브'
  },
  {
    id: 2,
    title: '트렌드 쇼트 컷',
    description: '올해 가장 인기 있는 쇼트 스타일. 청초하고 세련된 이미지를 연출합니다. 35,000원 / 30~40분',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/iW1yqIbzNhj5_e4d47f9b.jpg',
    designer: '수호 (실장)',
    category: '커트'
  },
  {
    id: 3,
    title: '매직스트레이트 + 애쉬 컬러',
    description: '손상 없는 매직스트레이트와 트렌디한 애쉬 컬러의 조합. 부드럽고 고급스러운 분위기. 180,000원 / 3~4시간',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/q8Jykt3qBUjq_ae339ee0.jpeg',
    designer: '솔빈 (디자이너)',
    category: '스트레이트/컬러'
  },
  {
    id: 4,
    title: '레이어드 롱 웨이브',
    description: '길이감을 살린 우아한 레이어드 스타일. 움직임 있는 웨이브로 생기 있는 이미지. 40,000원 / 40~50분',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/NU6nf9yTczTE_43413932.jpeg',
    designer: '안나 (실장)',
    category: '웨이브'
  },
  {
    id: 5,
    title: '남성 아이롱펌',
    description: '자연스러운 매력의 남성 펌 스타일. 스타일링이 쉽고 관리가 간편합니다. 80,000원 / 2~3시간',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/maX6U9qkngWW_af4886a2.jpg',
    designer: '수호 (실장)',
    category: '남성 스타일'
  },
  {
    id: 6,
    title: '젤리펌 + 클리닉',
    description: '손상된 머릿결을 케어하면서 펌 효과를 살린 프리미엄 시술. 윤기 있고 건강한 머릿결. 160,000원 / 3~3.5시간',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/z065O0xq53cT_40a2c4d0.jpg',
    designer: '솔빈 (디자이너)',
    category: '케어 + 펌'
  },
  {
    id: 7,
    title: '헤드스파컷',
    description: '두피 건강을 지키며 스타일링하는 케어 중심 커트. 50,000원 / 40~50분',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/lfPcmXRcCkrc_fb778c52.png',
    designer: '솔빈 (디자이너)',
    category: '커트'
  },
  {
    id: 8,
    title: '다이아 블리치 컬러',
    description: '밝은 톤의 블리치 컬러. 개성 있고 트렌디한 스타일. 100,000원 / 2~3시간',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/WMPZZaLRt9kM_f18fe406.webp',
    designer: '안나 (실장)',
    category: '스트레이트/컬러'
  },
  {
    id: 9,
    title: '매직 설팅펌',
    description: '매직스트레이트와 설팅펌의 조합. 손상 최소화하며 완벽한 스타일. 150,000원 / 3~4시간',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/wY1L9zUhpXxe_78cfc05c.jpg',
    designer: '솔빈 (디자이너)',
    category: '펌/웨이브'
  },
  {
    id: 10,
    title: '프리미엄 클리닉',
    description: '고급 영양 성분으로 깊은 케어. 윤기 있고 건강한 머릿결. 80,000원 / 1.5~2시간',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/iW1yqIbzNhj5_e4d47f9b.jpg',
    designer: '솔빈 (디자이너)',
    category: '케어 + 펌'
  },
  {
    id: 11,
    title: '릴렉싱 헤드스파',
    description: '60분 프리미엄 헤드스파. 완전한 이완과 두피 재생. 120,000원 / 60분',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/q8Jykt3qBUjq_ae339ee0.jpeg',
    designer: '솔빈 (디자이너)',
    category: '웨이브'
  },
  {
    id: 12,
    title: '루트 스테이닝',
    description: '뿌리 염색으로 깔끔한 정돈. 유지 관리 용이. 70,000원 / 1~1.5시간',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/110903155/eXjKMB8VtT6ULVPXcfBvVn/z065O0xq53cT_40a2c4d0.jpg',
    designer: '안나 (실장)',
    category: '스트레이트/컬러'
  }
];

export default function MonthlyStyleSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredStyles = selectedCategory === 'all' 
    ? monthlyStyles 
    : monthlyStyles.filter(style => style.category === selectedCategory);

  if (filteredStyles.length === 0) return null;

  const categories = ['all', '커트', '펌/웨이브', '스트레이트/컬러', '웨이브', '케어 + 펌'];

  const handlePrev = () => {
    setCurrentIndex(prev => (prev - 1 + filteredStyles.length) % filteredStyles.length);
  };

  const handleNext = () => {
    setCurrentIndex(prev => (prev + 1) % filteredStyles.length);
  };

  const currentStyle = filteredStyles[currentIndex];

  return (
    <section id="monthly-style" className="py-20 bg-deep-black text-ivory">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-sm tracking-widest text-gold mb-3">FEATURED STYLES</p>
          <h2 className="text-4xl md:text-5xl font-light mb-4">
            이달의 <span className="font-serif italic text-gold">스타일</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            TONI&GUY 홍제점의 디자이너들이 추천하는 이달의 인기 스타일입니다.
            당신의 매력을 더욱 돋보이게 할 스타일을 찾아보세요.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map(category => {
              const categoryLabel = {
                'all': '전체',
                '커트': '커트',
                '펌/웨이브': '펌/웨이브',
                '스트레이트/컬러': '스트레이트/컬러',
                '웨이브': '웨이브',
                '케어 + 펌': '케어 + 펌'
              };
              return (
                <button
                  key={category}
                  onClick={() => {
                    setSelectedCategory(category);
                    setCurrentIndex(0);
                  }}
                  className={`px-4 py-2 text-sm font-medium transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-gold text-deep-black'
                      : 'bg-transparent border border-gold text-gold hover:bg-gold hover:text-deep-black'
                  }`}
                >
                  {categoryLabel[category as keyof typeof categoryLabel]}
                </button>
              );
            })}
        </div>

        {/* Main Style Display */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-12">
          {/* Image */}
          <div className="relative aspect-square overflow-hidden bg-gray-900">
            <img
              src={currentStyle.image}
              alt={currentStyle.title}
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-deep-black via-transparent to-transparent opacity-60"></div>
            
            {/* Style Number */}
            <div className="absolute top-6 right-6 bg-gold text-deep-black px-4 py-2 text-sm font-semibold">
              {currentIndex + 1} / {filteredStyles.length}
            </div>
          </div>

          {/* Content */}
          <div className="space-y-6">
            <div>
              <p className="text-gold text-sm tracking-widest mb-2">{currentStyle.category}</p>
              <h3 className="text-3xl md:text-4xl font-light mb-4">{currentStyle.title}</h3>
              <p className="text-gray-300 leading-relaxed text-lg mb-4">{currentStyle.description}</p>
              <div className="text-sm text-gray-400 space-y-1">
                <p>💰 가격 및 소요시간은 설명 참조</p>
              </div>
            </div>

            {/* Designer Info */}
            <div className="pt-6 border-t border-gray-700">
              <p className="text-sm text-gray-400 mb-2">담당 디자이너</p>
              <p className="text-xl font-medium text-gold">{currentStyle.designer}</p>
            </div>

            {/* Navigation Buttons */}
            <div className="flex gap-4 pt-6">
              <button
                onClick={handlePrev}
                className="flex items-center justify-center w-12 h-12 border border-gold text-gold hover:bg-gold hover:text-deep-black transition-all duration-300"
                aria-label="Previous style"
              >
                <ChevronLeft size={20} />
              </button>
              <button
                onClick={handleNext}
                className="flex items-center justify-center w-12 h-12 bg-gold text-deep-black hover:bg-opacity-90 transition-all duration-300"
                aria-label="Next style"
              >
                <ChevronRight size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Thumbnail Navigation */}
        <div className="flex gap-4 overflow-x-auto pb-4 justify-center">
          {filteredStyles.map((style, index) => (
            <button
              key={style.id}
              onClick={() => setCurrentIndex(index)}
              className={`flex-shrink-0 w-20 h-20 overflow-hidden transition-all duration-300 ${
                index === currentIndex
                  ? 'ring-2 ring-gold scale-110'
                  : 'opacity-60 hover:opacity-100'
              }`}
            >
              <img
                src={style.image}
                alt={style.title}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <p className="text-gray-400 mb-4">이 스타일이 마음에 드세요?</p>
          <a
            href="https://m.blog.naver.com/p750616"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-3 bg-gold text-deep-black font-medium hover:bg-opacity-90 transition-all duration-300"
          >
            블로그에서 더 보기
          </a>
        </div>
      </div>
    </section>
  );
}
