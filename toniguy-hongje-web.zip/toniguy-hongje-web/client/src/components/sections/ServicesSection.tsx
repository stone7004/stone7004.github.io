import { useEffect, useRef, useState } from 'react';

const services = [
  {
    num: '01',
    name: 'Cut',
    nameKo: '커트',
    desc: '두상과 얼굴형을 분석해 최적화된 커트를 제안합니다. 남성 커트부터 여성 스타일링까지 전문 디자이너가 담당합니다.'
  },
  {
    num: '02',
    name: 'Color',
    nameKo: '컬러 · 염색',
    desc: '실버그레이, 코발트 애쉬, 레드브라운, 바이올렛 등 트렌드 컬러를 두피 건강을 지키며 구현합니다.'
  },
  {
    num: '03',
    name: 'Perm',
    nameKo: '펌',
    desc: '시크릿 투톤, 바이올렛 염색, 클리닉 매직 등 다양한 펌 기술로 원하시는 웨이브를 완성합니다.'
  },
  {
    num: '04',
    name: 'Treatment',
    nameKo: '트리트먼트 · 클리닉',
    desc: '손상된 모발을 회복시키는 맞춤형 트리트먼트. 촉촉한 클리닉 매직으로 건강하고 탄력 있는 모발을 되찾으세요.'
  },
  {
    num: '05',
    name: 'Scalp',
    nameKo: '두피 케어',
    desc: '두피 분석부터 맞춤 케어까지. 건강한 두피에서 아름다운 머리카락이 시작됩니다.'
  },
  {
    num: '06',
    name: 'Hair Clinic',
    nameKo: '모발 클리닉',
    desc: '단계별로 필요한 영양분을 상담 후 모발에 맞게 집중 케어합니다. 팀장님이 직접 시술해드립니다.'
  },
  {
    num: '07',
    name: 'Scalp Covering',
    nameKo: '두피 커버링',
    desc: '김혜진 원장님이 직접 시술하는 두피 커버링 전용 서비스. 자세한 문의는 매장으로 연락 주시면 상담 후 시술을 진행합니다.'
  }
];

export default function ServicesSection() {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="services" className="py-24 md:py-32 bg-[#0d0c0b]">
      <div className="container max-w-6xl">
        <div
          ref={ref}
          className={`flex flex-col md:flex-row md:justify-between md:items-end gap-8 mb-20 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div>
            <div className="section-tag">Our Services</div>
            <h2 className="section-title">시술 안내</h2>
          </div>
          <a
            href="https://m.blog.naver.com/p750616"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary"
          >
            블로그에서 더 보기 →
          </a>
        </div>

        <div className="grid md:grid-cols-4 gap-px bg-white/5 p-px">
          {services.map((service, idx) => (
            <div
              key={service.num}
              className={`card-service transition-all duration-1000 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${idx * 100}ms` }}
            >
              <div className="font-cormorant text-5xl font-light text-gold/30 mb-4">
                {service.num}
              </div>
              <h3 className="text-xl font-light text-ivory mb-1">{service.name}</h3>
              <p className="tag-font text-medium-gray mb-4">{service.nameKo}</p>
              <p className="text-sm text-light-gray leading-relaxed mb-6">
                {service.desc}
              </p>
              <a href="#" className="tag-font text-gold hover:text-gold-light transition-colors">
                자세히 보기 →
              </a>
            </div>
          ))}

          <div className="bg-gold p-8 flex flex-col justify-between">
            <div>
              <div className="font-cormorant text-5xl font-light text-black/20 mb-4">08</div>
              <h3 className="text-xl font-light text-black mb-1">예약하기</h3>
              <p className="tag-font text-black/60 mb-6">Reservation</p>
              <p className="text-sm text-black/65 leading-relaxed mb-8">
                전화, 네이버, 카카오톡으로 예약하실 수 있습니다.
              </p>
            </div>
            <div className="space-y-3">
              <a href="tel:+82-2-396-2805" className="block font-cormorant text-2xl font-light text-black hover:text-black/70 transition-colors">
                02) 396-2805
              </a>
              <a href="http://pf.kakao.com/_ZHCXj" target="_blank" rel="noopener noreferrer" className="block text-sm font-medium text-black hover:text-black/70 transition-colors">
                카카오톡 상담
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
