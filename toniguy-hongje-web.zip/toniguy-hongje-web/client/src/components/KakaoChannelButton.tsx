import { MessageCircle } from 'lucide-react';

interface KakaoChannelButtonProps {
  variant?: 'floating' | 'inline' | 'footer';
  className?: string;
}

export default function KakaoChannelButton({ variant = 'floating', className = '' }: KakaoChannelButtonProps) {
  const kakaoChannelUrl = 'http://pf.kakao.com/_ZHCXj';

  const handleKakaoClick = () => {
    window.open(kakaoChannelUrl, '_blank', 'width=400,height=600');
  };

  if (variant === 'floating') {
    return (
      <button
        onClick={handleKakaoClick}
        className={`fixed bottom-8 right-8 z-40 flex items-center justify-center w-14 h-14 rounded-full shadow-lg transition-all duration-300 hover:scale-110 hover:shadow-xl ${className}`}
        style={{
          backgroundColor: '#FFE812',
          color: '#3C1E1E'
        }}
        title="카카오톡 채널로 상담하기"
        aria-label="카카오톡 채널 상담"
      >
        <MessageCircle className="w-6 h-6" />
      </button>
    );
  }

  if (variant === 'inline') {
    return (
      <button
        onClick={handleKakaoClick}
        className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 hover:opacity-90 ${className}`}
        style={{
          backgroundColor: '#FFE812',
          color: '#3C1E1E'
        }}
      >
        <MessageCircle className="w-5 h-5" />
        <span className="font-medium">카카오톡 상담</span>
      </button>
    );
  }

  if (variant === 'footer') {
    return (
      <a
        href={kakaoChannelUrl}
        target="_blank"
        rel="noopener noreferrer"
        className={`inline-flex items-center gap-2 text-gold hover:text-gold-light transition-colors ${className}`}
      >
        <MessageCircle className="w-4 h-4" />
        <span>카카오톡 채널</span>
      </a>
    );
  }

  return null;
}
