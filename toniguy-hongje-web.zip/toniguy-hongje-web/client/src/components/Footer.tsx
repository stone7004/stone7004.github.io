import { Instagram, Youtube, MessageCircle, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t py-12" style={{ backgroundColor: '#000000', borderColor: 'rgba(255,255,255,0.1)' }}>
      <div className="container">
        <div className="grid md:grid-cols-2 gap-12 mb-12">
          <div>
            <a href="#" className="nav-font text-lg tracking-widest block mb-4" style={{ color: '#f4efe8' }}>
              TONI&GUY · HONGJE
            </a>
            <p className="nav-font text-xs leading-relaxed" style={{ color: '#6a6460' }}>
              서울특별시 서대문구 통일로 437<br />
              홍제치유온한의원 2층<br />
              TEL. 02) 396-2805 · 런던패션위크 공식지점
            </p>
            <p className="nav-font text-xs mt-4" style={{ color: 'rgba(255,255,255,0.1)' }}>
              © 2026 TONI&GUY KOREA · HONGJE. All rights reserved.
            </p>
            <p className="nav-font text-xs mt-6" style={{ color: '#6a6460' }}>
              <span className="block">홈페이지 제작문의</span>
              <span className="block">김석기 010-8719-9226</span>
            </p>
          </div>
          <div>
            <div className="flex gap-6">
              <a
                href="https://www.instagram.com/toniguy_hongje"
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors"
                style={{ color: '#c8c2ba' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#b8965a')}
                onMouseLeave={(e) => (e.currentTarget.style.color = '#c8c2ba')}
                aria-label="Instagram"
              >
                <Instagram size={24} />
              </a>
              <a
                href="https://www.tiktok.com/@toni_guy777"
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors"
                style={{ color: '#c8c2ba' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#b8965a')}
                onMouseLeave={(e) => (e.currentTarget.style.color = '#c8c2ba')}
                aria-label="TikTok"
              >
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.68v13.67a2.4 2.4 0 1 1-2.4-2.4c.2 0 .41.02.6.05V9.41a5.5 5.5 0 0 0-.6-.05A5.5 5.5 0 0 0 1 14.5a5.5 5.5 0 0 0 5.5 5.5 5.5 5.5 0 0 0 5.5-5.5V9.59a7.35 7.35 0 0 0 4.3 1.38V7.37A4.85 4.85 0 0 1 19.59 6.69z" />
                </svg>
              </a>
              <a
                href="https://youtube.com/@tonihongje2580"
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors"
                style={{ color: '#c8c2ba' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#b8965a')}
                onMouseLeave={(e) => (e.currentTarget.style.color = '#c8c2ba')}
                aria-label="YouTube"
              >
                <Youtube size={24} />
              </a>
              <a
                href="http://pf.kakao.com/_ZHCXj"
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors"
                style={{ color: '#c8c2ba' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#b8965a')}
                onMouseLeave={(e) => (e.currentTarget.style.color = '#c8c2ba')}
                aria-label="Kakao Channel"
              >
                <MessageCircle size={24} />
              </a>
              <a
                href="https://www.facebook.com/share/16bV1khLpi/"
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors"
                style={{ color: '#c8c2ba' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#b8965a')}
                onMouseLeave={(e) => (e.currentTarget.style.color = '#c8c2ba')}
                aria-label="Facebook"
              >
                <Facebook size={24} />
              </a>
              <a
                href="https://m.blog.naver.com/p750616"
                target="_blank"
                rel="noopener noreferrer"
                className="nav-font text-xs uppercase tracking-wider transition-colors"
                style={{ color: '#c8c2ba' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = '#b8965a')}
                onMouseLeave={(e) => (e.currentTarget.style.color = '#c8c2ba')}
              >
                Blog
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
