# TONI&GUY 홍제점 웹사이트 개발 가이드

## 프로젝트 개요
- **프로젝트명:** toniguy-hongje-web
- **배포 주소:** https://toniguyweb-exjkmb8v.manus.space
- **프레임워크:** React 19 + Vite + Tailwind CSS 4
- **배포 플랫폼:** Manus (자동 배포)

---

## 1. 프로젝트 구조

```
toniguy-hongje-web/
├── client/
│   ├── public/              # 작은 설정 파일만 (favicon, robots.txt)
│   ├── src/
│   │   ├── pages/           # 페이지 컴포넌트
│   │   ├── components/      # 재사용 가능한 UI 컴포넌트
│   │   │   ├── sections/    # 섹션 컴포넌트
│   │   │   ├── Footer.tsx   # 푸터 (연락처, 소셜 미디어)
│   │   │   ├── Navigation.tsx
│   │   │   ├── KakaoChannelButton.tsx
│   │   │   └── Map.tsx
│   │   ├── App.tsx          # 라우팅 및 레이아웃
│   │   ├── main.tsx         # React 진입점
│   │   └── index.css        # 글로벌 스타일 (디자인 토큰)
│   └── index.html
├── server/                  # 플레이스홀더 (정적 배포용)
├── package.json
├── vite.config.ts
├── tailwind.config.ts
└── netlify.toml            # Netlify 배포 설정 (선택사항)
```

---

## 2. 주요 컴포넌트 및 섹션

### 2.1 Hero Section (HeroSection.tsx)
- **배경 이미지:** TONI&GUY 매장 인테리어 사진 (CDN URL)
- **텍스트:** "Art of Hair" 타이틀, 주소, 예약 버튼
- **반응형:** 모바일에서 텍스트 크기 조정 (text-xs md:text-sm)
- **수정 시 주의:** 배경 이미지 URL 변경 시 캐시 버스팅 필요

### 2.2 Designers Section (DesignersSection.tsx)
- **스타일리스트 10명:** 엄기억, 안나, 가희, 수호, 은지, 서진, 솔빈, 케빈, 진, 지수
- **각 프로필 포함:**
  - 프로필 사진 (CDN URL)
  - 직급 (Art Director, Senior Designer 등)
  - 경력 (년수)
  - 전문분야 (5개 이상)
  - 대표시술 (3개, 가격 포함)
  - 자격사항
- **수정 방법:** `client/src/components/sections/DesignersSection.tsx` 파일의 `designers` 배열 수정

### 2.3 Gallery Section (GallerySection.tsx)
- **그리드:** 4x3 (12개 항목 표시)
- **내용:** 10명 스타일리스트 프로필 사진
- **호버 효과:** 이름과 직급 표시

### 2.4 Services Section (ServicesSection.tsx)
- **서비스 목록:** 커트, 컬러, 펌, 트리트먼트, 두피케어, 모발클리닉, 두피커버링
- **각 서비스:** 설명, 예약 버튼 (전화, 네이버, 카카오톡)

### 2.5 Footer (Footer.tsx)
- **정보:**
  - 주소: 서울특별시 서대문구 통일로 437, 홍제치유온한의원 2층
  - 전화: 02) 396-2805
  - 소셜 미디어: Instagram, TikTok, YouTube, Kakao Channel, Facebook, Blog
  - **웹사이트 제작 문의:** 김석기 010-8719-9226

---

## 3. 이미지 관리 (중요!)

### 3.1 이미지 저장 위치
- **로컬 저장:** `/home/ubuntu/webdev-static-assets/` (프로젝트 외부)
- **배포 시:** 모든 이미지는 CDN URL로 참조

### 3.2 이미지 업로드 방법
```bash
# 이미지 파일을 CDN에 업로드하고 URL 받기
manus-upload-file --webdev /path/to/image.jpg
```

### 3.3 현재 사용 중인 이미지
- **Hero 배경:** TONI&GUY 매장 인테리어 사진 (CDN URL)
- **스타일리스트 프로필:** 각 스타일리스트 사진 (CDN URL)
- **갤러리:** 스타일리스트 프로필 사진 재사용

---

## 4. 예약 시스템

### 4.1 예약 버튼 종류
1. **전화 예약:** `tel:+82-2-396-2805` (국제 형식)
2. **네이버 예약:** https://booking.naver.com/booking/13/bizes/...
3. **카카오톡 채널:** http://pf.kakao.com/_ZHCXj

### 4.2 예약 버튼 위치
- ReserveCTASection (메인 예약 섹션)
- ServicesSection (각 서비스 카드)
- KakaoChannelButton (플로팅 버튼, 우측 하단)

### 4.3 수정 방법
- 버튼 텍스트/링크: 각 섹션 컴포넌트 파일에서 수정
- 플로팅 버튼: `App.tsx`에서 `<KakaoChannelButton />` 제어

---

## 5. 소셜 미디어 링크

| 플랫폼 | URL | 위치 |
|--------|-----|------|
| Instagram | https://www.instagram.com/toniguy_hongje | Footer, Navigation |
| TikTok | https://www.tiktok.com/@toni_guy777 | Footer |
| YouTube | https://youtube.com/@tonihongje2580 | Footer |
| Kakao Channel | http://pf.kakao.com/_ZHCXj | Footer, 플로팅 버튼 |
| Facebook | https://www.facebook.com/share/16bV1khLpi/ | Footer |
| Naver Blog | https://m.blog.naver.com/p750616 | Footer |

---

## 6. 영업 정보

- **영업시간:** 매일 10:00 - 19:00 (연중무휴)
- **주차:** 협소 (공용 주차장 이용)
- **위치:** 홍제치유온한의원 2층

---

## 7. 수정 및 배포 절차

### 7.1 로컬 수정
```bash
# 프로젝트 디렉토리로 이동
cd /home/ubuntu/toniguy-hongje-web

# 개발 서버 실행 (자동으로 실행됨)
pnpm run dev

# 브라우저에서 확인
# https://3000-i7qabiwz0krv0rh2m4rp6-70da5525.sg1.manus.computer
```

### 7.2 파일 수정 예시

#### 예시 1: 스타일리스트 정보 수정
```typescript
// client/src/components/sections/DesignersSection.tsx
const designers = [
  {
    id: 1,
    name: "엄기억",
    title: "Art Director",
    image: "https://cdn-url/profile-image.jpg",
    experience: "25년",
    specialties: ["커트", "컬러", "펌", "트리트먼트", "두피케어"],
    services: [
      { name: "커트", price: "50,000원", time: "30분" },
      { name: "컬러", price: "80,000원", time: "90분" },
      { name: "펌", price: "100,000원", time: "120분" }
    ],
    certifications: ["국가자격증", "런던패션위크 공식 스타일리스트"]
  },
  // ... 다른 스타일리스트
];
```

#### 예시 2: 서비스 추가
```typescript
// client/src/components/sections/ServicesSection.tsx
const services = [
  {
    id: 1,
    title: "커트",
    description: "최신 트렌드를 반영한 맞춤형 커트",
    icon: Scissors,
  },
  // 새 서비스 추가
  {
    id: 8,
    title: "새로운 서비스",
    description: "설명",
    icon: Icon,
  },
];
```

#### 예시 3: Hero 배경 이미지 변경
```typescript
// client/src/components/sections/HeroSection.tsx
const backgroundImage = "https://cdn-url/new-hero-image.jpg";
// 또는 캐시 버스팅
const backgroundImage = "https://cdn-url/new-hero-image.jpg?v=2";
```

### 7.3 배포 절차
1. **파일 수정** (위의 예시 참고)
2. **개발 서버에서 확인** (자동 새로고침)
3. **Checkpoint 저장:**
   ```bash
   # Manus UI에서 "Save Checkpoint" 클릭
   # 또는 CLI 사용 (제공되면)
   ```
4. **자동 배포** (Manus가 자동으로 배포)
5. **배포 주소에서 확인:** https://toniguyweb-exjkmb8v.manus.space

---

## 8. 디자인 토큰 (index.css)

### 8.1 색상 팔레트
- **주색:** #b8965a (골드)
- **배경:** #000000 (검은색)
- **텍스트:** #f4efe8 (크림색)
- **보조:** #6a6460 (갈색)

### 8.2 폰트
- **제목:** 'Playfair Display' (serif)
- **본문:** 'Noto Sans KR' (sans-serif)

### 8.3 수정 방법
```css
/* client/src/index.css */
@layer base {
  :root {
    --primary: 184 50% 50%;  /* OKLCH 형식 */
    --background: 0 0% 0%;
    --foreground: 30 20% 95%;
  }
}
```

---

## 9. 자주 하는 실수 및 해결법

### 9.1 이미지가 배포되지 않음
- **원인:** 로컬 경로 사용 (예: `/src/assets/image.jpg`)
- **해결:** CDN URL 사용 (예: `https://cdn.../image.jpg`)

### 9.2 배경 이미지가 변경되지 않음
- **원인:** 브라우저 캐시
- **해결:** 캐시 버스팅 (URL에 `?v=1` 추가)

### 9.3 모바일에서 텍스트가 잘림
- **원인:** 반응형 클래스 누락
- **해결:** `md:` 프리픽스로 데스크톱 스타일 분리

### 9.4 예약 버튼이 작동하지 않음
- **원인:** 잘못된 전화번호 형식
- **해결:** `tel:+82-2-396-2805` (국제 형식 사용)

---

## 10. 유용한 명령어

```bash
# 개발 서버 시작
pnpm run dev

# 프로덕션 빌드
pnpm run build

# 빌드 결과 확인
pnpm run preview

# 타입스크립트 체크
pnpm run type-check

# 린트 확인
pnpm run lint
```

---

## 11. 문의 및 지원

- **웹사이트 제작 문의:** 김석기 010-8719-9226
- **Manus 배포 주소:** https://toniguyweb-exjkmb8v.manus.space
- **프로젝트 경로:** `/home/ubuntu/toniguy-hongje-web`

---

## 12. 체크리스트 (수정 전 확인)

- [ ] 수정할 파일 경로 확인
- [ ] 이미지는 CDN URL 사용
- [ ] 전화번호 형식 확인 (`tel:+82-2-396-2805`)
- [ ] 모바일 반응형 테스트
- [ ] 개발 서버에서 확인 후 배포
- [ ] Checkpoint 저장
- [ ] 배포 주소에서 최종 확인

---

**마지막 업데이트:** 2026년 4월 2일
**최종 Checkpoint:** b3ab7f85 (Footer에 웹사이트 제작 문의 정보 추가)
